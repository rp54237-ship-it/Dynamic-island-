package com.example.dynamicisland

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private var permissionStatus: TextView? = null

    private fun dp(value: Float): Int {
        return (value * resources.displayMetrics.density + 0.5f).toInt()
    }

    private fun fullWidth(height: Int): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (height < 0) height else dp(height.toFloat())
        )
    }

    private fun addButton(label: String, action: () -> Unit): Button {
        val button = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }
        val params = fullWidth(54).apply {
            setMargins(0, dp(6f), 0, dp(6f))
        }
        root.addView(button, params)
        return button
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22f), dp(24f), dp(22f), dp(24f))
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "Dynamic Island (Kotlin)"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        root.addView(title, fullWidth(64))

        val description = TextView(this).apply {
            text = "A modern floating island for notifications, battery status and media sessions in Kotlin."
            textSize = 15f
            gravity = Gravity.CENTER
        }
        root.addView(description, fullWidth(80))

        permissionStatus = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(12f), 0, dp(12f))
        }
        root.addView(permissionStatus, fullWidth(-2))

        addButton("1. Enable Overlay") {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                refreshStatus()
            }
        }

        addButton("2. Enable Notification Access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        addButton("3. Allow Notifications") {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
            } else {
                refreshStatus()
            }
        }

        addButton("Start Dynamic Island") { startIsland() }

        addButton("Stop Dynamic Island") {
            stopService(Intent(this, IslandService::class.java))
            refreshStatus()
        }

        setContentView(root)
        refreshStatus()
    }

    private fun startIsland() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }

        val intent = Intent(this, IslandService::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        refreshStatus()
    }

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val notifAccess = IslandNotificationListener.hasAccess(this)
        val postNotif = Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

        permissionStatus?.text = buildString {
            append("Overlay: ").append(if (overlay) "Enabled ✓" else "Not enabled ✗").append("\n")
            append("Notification Access: ").append(if (notifAccess) "Enabled ✓" else "Not enabled ✗").append("\n")
            append("Notification display: ").append(if (postNotif) "Granted ✓" else "Not granted ✗")
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }
}
