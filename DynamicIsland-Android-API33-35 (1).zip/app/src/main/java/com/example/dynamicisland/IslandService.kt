package com.example.dynamicisland

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class IslandService : Service() {

    companion object {
        private const val CHANNEL_ID = "dynamic_island_channel"
        private const val NOTIFICATION_ID = 1001

        @JvmStatic
        var instance: IslandService? = null
            private set
    }

    private var windowManager: WindowManager? = null
    private var islandRoot: FrameLayout? = null
    private lateinit var windowParams: WindowManager.LayoutParams

    private var isExpanded = false
    private val mainHandler = Handler(Looper.getMainLooper())

    // UI dimensions in px
    private var collapsedWidth = 0
    private var collapsedHeight = 0
    private var expandedWidth = 0
    private var expandedHeight = 0
    private var cornerRadius = 0

    // Views
    private lateinit var containerView: FrameLayout
    private lateinit var compactLayout: LinearLayout
    private lateinit var expandedLayout: LinearLayout
    private lateinit var compactLeftText: TextView
    private lateinit var compactRightText: TextView
    private lateinit var expandedTitle: TextView
    private lateinit var expandedSubtitle: TextView
    private lateinit var expandedDetail: TextView

    // State
    private var currentBatteryPercent = 100
    private var isCharging = false
    private var currentTrack: String? = null
    private var isPlayingMusic = false

    // Services
    private var mediaSessionManager: MediaSessionManager? = null
    private var activeMediaController: MediaController? = null
    private var vibrator: Vibrator? = null

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)

            val percent = BatteryUtils.percentage(level, scale)
            val charging = BatteryUtils.isChargingOrFull(status)

            if (percent != -1) {
                currentBatteryPercent = percent
            }

            if (charging != isCharging) {
                isCharging = charging
                onBatteryEvent(currentBatteryPercent, isCharging)
            }
        }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
        updateActiveMediaSession(controllers)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

        initDimensions()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification())

        setupFloatingIsland()
        registerBatteryReceiver()
        registerMediaListener()
    }

    private fun dp(value: Float): Int {
        return (value * resources.displayMetrics.density + 0.5f).toInt()
    }

    private fun initDimensions() {
        collapsedWidth = dp(160f)
        collapsedHeight = dp(36f)
        expandedWidth = dp(340f)
        expandedHeight = dp(150f)
        cornerRadius = dp(24f)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Dynamic Island Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active floating pill overlay on screen"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("Dynamic Island Active (Kotlin)")
            .setContentText("Tap overlay to expand or interact")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    private fun setupFloatingIsland() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        windowParams = WindowManager.LayoutParams(
            collapsedWidth,
            collapsedHeight,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(12f)
        }

        islandRoot = FrameLayout(this)
        containerView = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = this@IslandService.cornerRadius.toFloat()
            }
            clipToOutline = true
        }

        setupCompactLayout()
        setupExpandedLayout()

        containerView.addView(compactLayout)
        containerView.addView(expandedLayout)
        islandRoot?.addView(
            containerView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        setupTouchGestures()
        windowManager?.addView(islandRoot, windowParams)
    }

    private fun setupCompactLayout() {
        compactLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12f), 0, dp(12f), 0)
        }

        compactLeftText = TextView(this).apply {
            text = "⚡ 100%"
            setTextColor(Color.WHITE)
            textSize = 12f
        }

        val spacer = View(this)
        val spacerParams = LinearLayout.LayoutParams(0, 1, 1f)

        compactRightText = TextView(this).apply {
            text = "Island"
            setTextColor(Color.LTGRAY)
            textSize = 12f
        }

        compactLayout.addView(compactLeftText)
        compactLayout.addView(spacer, spacerParams)
        compactLayout.addView(compactRightText)
    }

    private fun setupExpandedLayout() {
        expandedLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
            visibility = View.GONE
        }

        expandedTitle = TextView(this).apply {
            text = "Dynamic Island"
            setTextColor(Color.WHITE)
            textSize = 16f
        }

        expandedSubtitle = TextView(this).apply {
            text = "Active Kotlin service"
            setTextColor(Color.LTGRAY)
            textSize = 13f
        }

        expandedDetail = TextView(this).apply {
            text = "Battery: 100% | System Normal"
            setTextColor(Color.GRAY)
            textSize = 12f
            setPadding(0, dp(8f), 0, 0)
        }

        expandedLayout.addView(expandedTitle)
        expandedLayout.addView(expandedSubtitle)
        expandedLayout.addView(expandedDetail)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTouchGestures() {
        islandRoot?.setOnTouchListener(object : View.OnTouchListener {
            private var startY = 0f
            private var startTime = 0L

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startY = event.rawY
                        startTime = System.currentTimeMillis()
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val diffY = event.rawY - startY
                        val duration = System.currentTimeMillis() - startTime
                        if (abs(diffY) < dp(10f) && duration < 300) {
                            toggleExpand()
                        } else if (diffY < -dp(30f) && isExpanded) {
                            collapseIsland()
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun toggleExpand() {
        if (isExpanded) collapseIsland() else expandIsland()
    }

    private fun triggerHaptic() {
        vibrator?.let { vib ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(25)
            }
        }
    }

    private fun expandIsland() {
        if (isExpanded) return
        isExpanded = true
        triggerHaptic()

        compactLayout.visibility = View.GONE
        expandedLayout.visibility = View.VISIBLE

        animateIslandSize(collapsedWidth, expandedWidth, collapsedHeight, expandedHeight, dp(24f), dp(32f))
    }

    private fun collapseIsland() {
        if (!isExpanded) return
        isExpanded = false
        triggerHaptic()

        expandedLayout.visibility = View.GONE
        compactLayout.visibility = View.VISIBLE

        animateIslandSize(expandedWidth, collapsedWidth, expandedHeight, collapsedHeight, dp(32f), dp(24f))
    }

    private fun animateIslandSize(fromW: Int, toW: Int, fromH: Int, toH: Int, fromR: Float, toR: Float) {
        val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280
            interpolator = OvershootInterpolator(0.85f)
        }

        animator.addUpdateListener { animation ->
            val fraction = animation.animatedValue as Float
            windowParams.width = (fromW + (toW - fromW) * fraction).toInt()
            windowParams.height = (fromH + (toH - fromH) * fraction).toInt()

            val bg = containerView.background as? GradientDrawable
            bg?.cornerRadius = fromR + (toR - fromR) * fraction

            if (islandRoot?.isAttachedToWindow == true) {
                windowManager?.updateViewLayout(islandRoot, windowParams)
            }
        }
        animator.start()
    }

    fun onExternalNotification(title: String, text: String, packageName: String) {
        mainHandler.post {
            val shortPkg = if (packageName.length > 8) packageName.substring(0, 8) else packageName
            compactLeftText.text = "🔔 $shortPkg"
            compactRightText.text = title

            expandedTitle.text = title
            expandedSubtitle.text = text
            expandedDetail.text = "From: $packageName"

            expandIsland()

            mainHandler.removeCallbacksAndMessages(null)
            mainHandler.postDelayed({ collapseIsland() }, 4000)
        }
    }

    private fun onBatteryEvent(percent: Int, charging: Boolean) {
        mainHandler.post {
            val batteryText = (if (charging) "⚡ " else "🔋 ") + "$percent%"
            compactLeftText.text = batteryText

            expandedTitle.text = if (charging) "Charging Connected" else "Battery Update"
            expandedSubtitle.text = batteryText + if (charging) " (Fast Charging)" else ""
            expandedDetail.text = "Current battery health: Normal"

            expandIsland()
            mainHandler.postDelayed({ collapseIsland() }, 3500)
        }
    }

    private fun registerBatteryReceiver() {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        registerReceiver(batteryReceiver, filter)
    }

    private fun registerMediaListener() {
        try {
            val compName = ComponentName(this, IslandNotificationListener::class.java)
            mediaSessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
            if (mediaSessionManager != null && IslandNotificationListener.hasAccess(this)) {
                mediaSessionManager?.addOnActiveSessionsChangedListener(sessionsListener, compName)
                updateActiveMediaSession(mediaSessionManager?.getActiveSessions(compName))
            }
        } catch (_: SecurityException) {
            // Handled when user has not yet allowed notification listener access
        }
    }

    private fun updateActiveMediaSession(controllers: List<MediaController>?) {
        if (!controllers.isNullOrEmpty()) {
            activeMediaController = controllers[0]
            val metadata = activeMediaController?.metadata
            if (metadata != null) {
                currentTrack = metadata.getString(MediaMetadata.METADATA_KEY_TITLE)
            }

            val state = activeMediaController?.playbackState
            isPlayingMusic = (state != null && state.state == PlaybackState.STATE_PLAYING)

            if (isPlayingMusic) {
                compactLeftText.text = "🎵 " + (currentTrack ?: "Playing")
                compactRightText.text = "▶"
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null

        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {}

        try {
            sessionsListener.let { mediaSessionManager?.removeOnActiveSessionsChangedListener(it) }
        } catch (_: Exception) {}

        if (islandRoot?.isAttachedToWindow == true && windowManager != null) {
            windowManager?.removeView(islandRoot)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
