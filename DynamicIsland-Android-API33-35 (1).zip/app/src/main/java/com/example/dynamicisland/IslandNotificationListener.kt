package com.example.dynamicisland

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {

    companion object {
        @JvmStatic
        fun hasAccess(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false

            val component = ComponentName(context, IslandNotificationListener::class.java)
            return enabled.contains(component.flattenToString())
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.notification == null) return
        if (packageName == sbn.packageName) return

        val notification = sbn.notification
        val title = notification.extras.getCharSequence(Notification.EXTRA_TITLE)
        var text = notification.extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
        if (text == null) {
            text = notification.extras.getCharSequence(Notification.EXTRA_TEXT)
        }

        IslandService.instance?.onExternalNotification(
            title = title?.toString() ?: "New notification",
            text = text?.toString() ?: "",
            packageName = sbn.packageName
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // Notification dismissed handling if required
    }
}
