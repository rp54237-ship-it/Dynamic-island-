package com.example.dynamicisland

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object BatteryUtils {

    /**
     * Calculates the battery percentage given level and scale.
     * Returns -1 if inputs are invalid.
     */
    @JvmStatic
    fun percentage(level: Int, scale: Int): Int {
        if (level < 0 || scale <= 0) {
            return -1
        }

        val computed = (level * 100f / scale).roundToInt()
        return max(0, min(100, computed))
    }

    /**
     * Checks if the device is currently in a charging or full state.
     * Android BatteryManager status:
     * 2 = BATTERY_STATUS_CHARGING
     * 5 = BATTERY_STATUS_FULL
     */
    @JvmStatic
    fun isChargingOrFull(status: Int): Boolean {
        return status == 2 || status == 5
    }
}
