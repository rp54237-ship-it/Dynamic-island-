# Dynamic Island for Android (API 33 – 35)

A fluid, production-grade floating Dynamic Island implementation for Android 13 (API 33) through Android 15 (API 35) written in pure Java.

---

## 📁 Project Structure

```
DynamicIsland/
├── settings.gradle
├── build.gradle
├── README.md
├── gradle/
│   └── wrapper/
│       └── gradle-wrapper.properties
└── app/
    ├── build.gradle
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml
        │   └── java/com/example/dynamicisland/
        │       ├── BatteryUtils.java
        │       ├── MainActivity.java
        │       ├── IslandNotificationListener.java
        │       └── IslandService.java
        └── test/
            └── java/com/example/dynamicisland/
                └── BatteryUtilsTest.java
```

---

## 🚀 How to Open & Run in Android Studio

1. **Download & Extract**:
   - Download the project as ZIP or clone this directory.
   - Open **Android Studio (Ladybug / Koala or newer)**.
   - Choose **File > Open** and select the `DynamicIsland` folder.
   - JDK Requirement: **JDK 17** (standard for Android Gradle Plugin 8.7+).

2. **Sync Gradle**:
   - Android Studio will automatically sync dependencies (`androidx.annotation`, `junit:4.13.2`).

3. **Run on Device or Emulator**:
   - Select an Android device or emulator running **Android 13 (API 33)+**.
   - Click **Run (Shift + F10)**.

---

## 🔑 Permissions & Android 14/15 Compatibility

The app requires three key permissions to function seamlessly:

1. **Display Over Other Apps (`android.permission.SYSTEM_ALERT_WINDOW`)**
   - Required to render the floating pill above all activities and the system status bar.
   - Granted via `Settings.ACTION_MANAGE_OVERLAY_PERMISSION`.

2. **Notification Listener (`android.permission.BIND_NOTIFICATION_LISTENER_SERVICE`)**
   - Enables real-time listening to incoming messages (WhatsApp, Telegram, Slack, etc.) and active media controllers (Spotify, YouTube Music).
   - Granted via `Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS`.

3. **Foreground Service Special Use (`FOREGROUND_SERVICE_SPECIAL_USE`)**
   - Compliant with strict Android 14+ Google Play policies using:
     ```xml
     <property
         android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
         android:value="User-enabled floating activity island" />
     ```

---

## ⚡ Manufacturer-Specific Optimizations

- **Xiaomi / POCO / Redmi (MIUI & HyperOS)**:
  - Enable **"Display pop-up windows while running in the background"** in App Info > Other permissions.
  - Disable MIUI Battery Saver for seamless background persistence.
- **Samsung One UI**:
  - Remove Dynamic Island from "Sleeping apps" in Device Care > Battery.
- **Realme / Oppo / OnePlus (ColorOS / OxygenOS)**:
  - Turn ON "Allow Auto-launch" and "Allow floating windows".

---

## 🧪 Running Unit Tests

To run the JUnit 4 tests:
```bash
./gradlew test
```
Or directly right-click on `BatteryUtilsTest.java` in Android Studio and select **Run 'BatteryUtilsTest'**.
